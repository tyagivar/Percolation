import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;


public class PercolationStats {
	private double[] arr;
	private int x;
	private int y;
	private double mean=-1;
	private double stddev=-1;
	
	/*Percolation Stats*/
	public PercolationStats(int n ,int trials) {
		if(n<=0 || trials<=0) {
			throw new IllegalArgumentException();
		}
		arr= new double[trials];
		for(int i=0; i<trials; i++) {
			Percolation pc= new Percolation(n);
			while(pc.percolates()== false) {
				x= StdRandom.uniform(1,n+1);
				y= StdRandom.uniform(1,n+1);
				pc.open(x, y);
			}
			arr[i]=((double)pc.numberOfOpenSites()/(n*n));
		}
	}
	
	/*Sample Mean of Percolation Threshold*/
	public double mean() {
		mean= StdStats.mean(arr);
		return mean;
	}
	
	/*Standard Deviation of Percolation Threshold*/
	public double stddev() {
		stddev= StdStats.stddev(arr);
		return stddev;
	}
	
	/*Low End-point of 95% Confidence Interval*/
	public double confidenceLo() {
		double x;
		if(mean==-1) {
			x= StdStats.mean(arr);
		}
		else {
			x= mean;
		}
		double s;
		if(stddev==-1) {
			s= StdStats.stddev(arr);
		}
		else {
			s= stddev;
		}
		double rootT= Math.pow(arr.length, 0.5);
		return (x-((1.96*s)/rootT));
	}
	
	/*High End-point of 95% Confidence Interval*/
	public double confidenceHi() {
		double x;
		if(mean==-1) {
			x= StdStats.mean(arr);
		}
		else {
			x= mean;
		}
		double s;
		if(stddev==-1) {
			s= StdStats.stddev(arr);
		}
		else {
			s= stddev;
		}
		double rootT= Math.pow(arr.length, 0.5);
		return (x+((1.96*s)/rootT));
	}
	
	/*Main Method for Testing*/
	public static void main(String[] args) {
		
		System.out.println("Please Enter The No. of Grids And Trials");
		
		int n=StdIn.readInt();
		int trials=StdIn.readInt();
		PercolationStats ps= new PercolationStats(n,trials);
		System.out.println(/*"95% confidence interval = ["+ps.confidenceLo()+","*/ +ps.confidenceHi()+"]");
		System.out.println("stddev                  = "+ps.stddev());
		System.out.println("mean                    = "+ps.mean());
		System.out.println("mean                    = "+ps.mean());
		System.out.println("stddev                  = "+ps.stddev());
		System.out.println("stddev                  = "+ps.stddev());
		System.out.println("stddev                  = "+ps.stddev());
		System.out.println("stddev                  = "+ps.stddev());
		System.out.println(/*"95% confidence interval = ["+ps.confidenceLo()+","*/ +ps.confidenceLo()+"]");
		System.out.println(/*"95% confidence interval = ["+ps.confidenceLo()+", "*/+ps.confidenceHi()+"]");
	}
}
