
import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
	
	private int[][] arr;
	private int NOS=0;
	private WeightedQuickUnionUF uf;
	private WeightedQuickUnionUF uf2;
	
	/*Constructor*/
	public Percolation(int n) {
		if(n<=0) {
			throw new IllegalArgumentException();
		}
		arr= new int[n][n];
		for(int i=0; i<n; i++) {
			for(int j=0; j<n; j++) {
				arr[i][j]=0;
			}
		}
		uf= new WeightedQuickUnionUF((arr.length*arr.length)+2);
		uf2=new WeightedQuickUnionUF((arr.length*arr.length)+1);
	}
	
	/*Converter*/
	private int xyTo1D(int x, int y) {
		validate(x,y);
		return ((x-1)*arr.length+y);
	}
	
	/*Validator*/
	private void validate(int x, int y) {
		if((x>=1 && x<=arr.length) && (y>=1 && y<=arr.length)) {
			return;
		}
		else {
			throw new IllegalArgumentException();
		}
	}
	
	/*isOpen*/
	public boolean isOpen(int row, int col) {
		validate(row,col);
		if(arr[row-1][col-1]==0) {
			return false;
		}
		else {
			return true;
		}
	}
	
	/*isFull*/
	public boolean isFull(int row, int col) {
		validate(row,col);
		return uf2.connected(0, xyTo1D(row,col));
	}
	
	/*numberofOpenSites*/
	public int numberOfOpenSites() {
		return NOS;
	}
	
	/*Open*/
	public void open(int row, int col) {
		validate(row,col);
		if(arr[row-1][col-1]== 1) {
			return;
		}
		arr[row-1][col-1]=1;
		NOS=NOS+1;
		if(row==1) {
			uf.union(xyTo1D(row, col), 0);
			uf2.union(xyTo1D(row, col), 0);
		}
		if(row==arr.length) {
			uf.union(xyTo1D(row, col), arr.length*arr.length+1);
		}
		if((row-1)>0) {
			if(isOpen(row-1,col)) {
				uf.union(xyTo1D(row,col), xyTo1D(row-1,col));
				uf2.union(xyTo1D(row,col), xyTo1D(row-1,col));
			}
		}
		if((row+1)<arr.length+1) {
			if(isOpen(row+1,col)) {
				uf.union(xyTo1D(row,col), xyTo1D(row+1,col));
				uf2.union(xyTo1D(row,col), xyTo1D(row+1,col));
			}
		}
		if((col-1)>0) {
			if(isOpen(row,col-1)) {
				uf.union(xyTo1D(row,col), xyTo1D(row,col-1));
				uf2.union(xyTo1D(row,col), xyTo1D(row,col-1));
			}
		}
		if((col+1)<arr.length+1) {
			if(isOpen(row,col+1)) {
				uf.union(xyTo1D(row,col), xyTo1D(row,col+1));
				uf2.union(xyTo1D(row,col), xyTo1D(row,col+1));
			}
		}
	}
	
	/*Percolates*/
	public boolean percolates() {
		return uf.connected(0, arr.length*arr.length+1);
	}
	
	/*Main Method for Testing*/
	public static void main(String[] args) {
		Percolation pc= new Percolation(20);
		System.out.println(pc.NOS);
		System.out.println(pc.isOpen(1, 1));
		pc.open(1, 1);
		pc.open(2, 1);
		pc.open(2, 2);
		pc.open(2, 3);
		pc.open(3, 3);
		pc.open(18, 1);
		System.out.println(pc.isFull(18, 1));
		System.out.println(pc.NOS);
		System.out.println(pc.isOpen(2,1));
		System.out.println(pc.percolates());
	}
	
}
